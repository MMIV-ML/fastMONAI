Replacement tumour segmentation masks for 17 cases from Vestibular-Schwannoma-SEG
Version 1.0

17 newly drawn tumour masks for scans whose original annotations contained errors.
These are the NL masks used in our study.
Contributors: Njål Lura, Satheshkumar Kaliyugarassan.
Labels: 0 background, 1 tumour. Native T1 geometry; no MRI images.
case_mapping.csv maps each mask to its original TCIA PatientID.
manifest.json records provenance and reference fingerprints.

Image source: TCIA Vestibular-Schwannoma-SEG version 2, DOI 10.7937/TCIA.9YTJ-5Q73.
Shapey et al. (2021), Scientific Data 8, 286.
Source paper DOI: 10.1038/s41597-021-01064-w.
License: CC BY 4.0. See LICENSE.txt.

Preparation: research/vestibular_schwannoma/data/README.md in
https://github.com/MMIV-ML/fastMONAI

Please cite our accompanying study paper when available (in preparation).
